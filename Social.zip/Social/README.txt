Halcyonic by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)


A somewhat unusual but interesting responsive site template. I did this one to test out a 
new pattern set I put together and I think it really came together well. As for use cases 
it's kind of unspecific so hey, use it for whatever.

Feedback, bug reports, and comments are not only welcome, but strongly encouraged :)

AJ
n33.co @n33co dribbble.com/n33


Credits:

	Demo Images:
		Unsplash (unsplash.com)
	
	Other:
		jQuery (jquery.com)
		html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		skel (n33.co)